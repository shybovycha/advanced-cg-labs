#pragma message("<glm/glmsetup.h> is deprecated, please include <glm/setup.hpp> instead")
#include "setup.hpp"
