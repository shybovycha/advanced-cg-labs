#pragma message("<glm/glm.h> is deprecated, please include <glm/glm.hpp> instead")
#include "glm.hpp"
