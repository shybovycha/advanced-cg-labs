=======================
GLI 0.2.1.1: 2010-05-12
-----------------------
. Fixed GCC build

=======================
GLI 0.2.1.0: 2010-02-15
-----------------------
. Added texelWrite function
. Fixed Visual Studio 2010 warnings
. Added readme.txt and copying.txt

=======================
GLI 0.2.0.0: 2010-01-10
-----------------------
. Updated API
. Removed Boost dependency

=======================
GLI 0.1.1.0: 2009-09-18
-----------------------
. Fixed DDS loader
. Added RGB8 to DDS loader
. Added component swizzle operation
. Added 32 bits integer components support
. Fixed texel fetch

=======================
GLI 0.1.0.0: 2009-03-28
-----------------------
. Added TGA loader
. Added DDS loader
. Added duplicate, crop, partial copy
. Added mipmaps generation.

===========================
Christophe Riccio, g.truc.creation|AT|gmail|DOT|com

